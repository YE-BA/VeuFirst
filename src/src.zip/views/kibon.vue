<template>
  <div class="home"></div>
</template>

<script>
// // @ is an alias to /src

export default {
  name: "playGround",
  components: {},
  data() {
    return {};
  },
  methods: {}
};
</script>
<style lang="scss">
</style>

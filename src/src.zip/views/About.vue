<template>
  <div class="about">
    <h1>This is an about page</h1>
    <h3>안녕하세요</h3>
  </div>
</template>

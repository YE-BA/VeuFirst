<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
// // @ is an alias to /src
export default {
  name: "CoreView",
  components: {},
  data() {
    return {};
  },
  methods: {}
};
</script>
<style lang="scss">
</style>